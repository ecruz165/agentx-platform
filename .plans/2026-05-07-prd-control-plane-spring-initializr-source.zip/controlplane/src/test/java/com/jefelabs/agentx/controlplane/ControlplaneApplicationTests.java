package com.jefelabs.agentx.controlplane;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlplaneApplicationTests {

	@Test
	void contextLoads() {
	}

}
